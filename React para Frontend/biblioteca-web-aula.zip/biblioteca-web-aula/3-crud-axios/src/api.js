import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL,
});

// um lugar só para transformar qualquer erro numa mensagem
api.interceptors.response.use(
  (resposta) => resposta,
  (erro) => {
    const mensagem = erro.response
      ? erro.response.data.erro
      : 'Sem conexão com a API.';
    return Promise.reject(new Error(mensagem));
  }
);

// GET /livros
export async function listarLivros() {
  const resposta = await api.get('/livros');
  return resposta.data;
}

// GET /generos
export async function listarGeneros() {
  const resposta = await api.get('/generos');
  return resposta.data;
}

// POST /livros
export async function cadastrarLivro(livro) {
  const resposta = await api.post('/livros', livro);
  return resposta.data;
}

// PUT /livros/:id
export async function atualizarLivro(id, livro) {
  const resposta = await api.put(`/livros/${id}`, livro);
  return resposta.data;
}

// DELETE /livros/:id
export async function excluirLivro(id) {
  await api.delete(`/livros/${id}`);
}
