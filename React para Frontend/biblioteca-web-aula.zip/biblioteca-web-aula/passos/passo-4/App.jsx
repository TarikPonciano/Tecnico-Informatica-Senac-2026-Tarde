import { useState } from 'react';
import Cabecalho from './components/Cabecalho';
import ListaLivros from './components/ListaLivros';

function App() {
  const [livros, setLivros] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');

  return (
    <main>
      <Cabecalho total={livros.length} />
      <ListaLivros livros={livros} />
    </main>
  );
}

export default App;
