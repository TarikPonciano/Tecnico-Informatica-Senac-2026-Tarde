function Cabecalho() {
  return (
    <header className="cabecalho">
      <h1>Biblioteca</h1>
      <p>Livros do acervo</p>
    </header>
  );
}

export default Cabecalho;
