import Cabecalho from './components/Cabecalho';
import CartaoLivro from './components/CartaoLivro';

const livro = {
  id_livro: 1,
  titulo_livro: 'Dom Casmurro',
  autor_livro: 'Machado de Assis',
  ano_livro: 1899,
  exemplares_livro: 3,
};

function App() {
  return (
    <main>
      <Cabecalho />
      <CartaoLivro livro={livro} />
    </main>
  );
}

export default App;
