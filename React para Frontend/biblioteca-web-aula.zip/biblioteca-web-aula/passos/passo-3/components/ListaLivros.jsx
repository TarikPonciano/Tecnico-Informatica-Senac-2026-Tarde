import CartaoLivro from './CartaoLivro';

function ListaLivros({ livros }) {
  return (
    <div className="grade">
      {livros.map((livro) => (
        <CartaoLivro key={livro.id_livro} livro={livro} />
      ))}
    </div>
  );
}

export default ListaLivros;
