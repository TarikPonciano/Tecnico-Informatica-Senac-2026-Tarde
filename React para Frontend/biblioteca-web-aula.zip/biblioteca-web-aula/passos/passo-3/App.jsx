import Cabecalho from './components/Cabecalho';
import ListaLivros from './components/ListaLivros';

const LIVROS_EXEMPLO = [
  { id_livro: 1, titulo_livro: 'Dom Casmurro', autor_livro: 'Machado de Assis',
    ano_livro: 1899, exemplares_livro: 3 },
  { id_livro: 2, titulo_livro: 'Iracema', autor_livro: 'José de Alencar',
    ano_livro: 1865, exemplares_livro: 2 },
  { id_livro: 3, titulo_livro: 'O Hobbit', autor_livro: 'J. R. R. Tolkien',
    ano_livro: 1937, exemplares_livro: 4 },
];

function App() {
  return (
    <main>
      <Cabecalho total={LIVROS_EXEMPLO.length} />
      <ListaLivros livros={LIVROS_EXEMPLO} />
    </main>
  );
}

export default App;
