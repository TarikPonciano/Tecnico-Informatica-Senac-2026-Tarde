import { useState } from 'react';
import Cabecalho from './components/Cabecalho';
import ListaLivros from './components/ListaLivros';
import Mensagem from './components/Mensagem';

function App() {
  const [livros, setLivros] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');

  return (
    <main>
      <Cabecalho total={livros.length} />
      {carregando && <Mensagem tipo="aviso" texto="Carregando..." />}
      {erro && <Mensagem tipo="erro" texto={erro} />}
      <ListaLivros livros={livros} />
    </main>
  );
}

export default App;
