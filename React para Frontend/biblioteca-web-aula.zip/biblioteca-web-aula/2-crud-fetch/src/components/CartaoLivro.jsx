function CartaoLivro({ livro, nomeGenero, onEditar, onExcluir }) {
  return (
    <div className="cartao">
      <h2>{livro.titulo_livro}</h2>
      <p>{livro.autor_livro}</p>
      <p className="detalhe">
        {nomeGenero} · {livro.ano_livro} · {livro.exemplares_livro} exemplares
      </p>
      <div className="acoes">
        <button className="secundario" onClick={() => onEditar(livro)}>Editar</button>
        <button className="perigo" onClick={() => onExcluir(livro)}>Excluir</button>
      </div>
    </div>
  );
}

export default CartaoLivro;
