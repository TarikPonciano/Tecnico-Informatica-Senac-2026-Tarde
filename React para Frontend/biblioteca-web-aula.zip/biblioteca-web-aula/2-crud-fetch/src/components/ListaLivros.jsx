import { useState } from 'react';
import CampoBusca from './CampoBusca';
import CartaoLivro from './CartaoLivro';

function ListaLivros({ livros, generos, onEditar, onExcluir }) {
  const [busca, setBusca] = useState('');

  const livrosFiltrados = livros.filter((livro) =>
    livro.titulo_livro.toLowerCase().includes(busca.toLowerCase())
  );

  function nomeDoGenero(id) {
    const genero = generos.find((g) => g.id_genero === id);
    return genero ? genero.nome_genero : '';
  }

  return (
    <>
      <CampoBusca valor={busca} onBuscar={setBusca} />
      <div className="grade">
        {livrosFiltrados.map((livro) => (
          <CartaoLivro
            key={livro.id_livro}
            livro={livro}
            nomeGenero={nomeDoGenero(livro.genero_id)}
            onEditar={onEditar}
            onExcluir={onExcluir}
          />
        ))}
      </div>
    </>
  );
}

export default ListaLivros;
