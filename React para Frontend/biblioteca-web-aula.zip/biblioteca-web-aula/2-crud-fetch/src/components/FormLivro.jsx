function FormLivro({ form, generos, editando, onAlterar, onSalvar, onCancelar }) {
  function enviar(evento) {
    evento.preventDefault();
    onSalvar();
  }

  return (
    <form className="formulario" onSubmit={enviar}>
      <label>
        Título
        <input name="titulo_livro" value={form.titulo_livro}
          onChange={onAlterar} required />
      </label>
      <label>
        Autor
        <input name="autor_livro" value={form.autor_livro}
          onChange={onAlterar} required />
      </label>
      <label>
        Ano
        <input name="ano_livro" type="number" value={form.ano_livro}
          onChange={onAlterar} required />
      </label>
      <label>
        Exemplares
        <input name="exemplares_livro" type="number" value={form.exemplares_livro}
          onChange={onAlterar} required />
      </label>
      <label>
        Gênero
        <select name="genero_id" value={form.genero_id}
          onChange={onAlterar} required>
          <option value="">Escolha...</option>
          {generos.map((genero) => (
            <option key={genero.id_genero} value={genero.id_genero}>
              {genero.nome_genero}
            </option>
          ))}
        </select>
      </label>
      <div className="acoes">
        <button type="submit">
          {editando ? 'Salvar alterações' : 'Cadastrar'}
        </button>
        {editando && (
          <button type="button" className="secundario" onClick={onCancelar}>
            Cancelar
          </button>
        )}
      </div>
    </form>
  );
}

export default FormLivro;
