import { useEffect, useState } from 'react';
import Cabecalho from './components/Cabecalho';
import FormLivro from './components/FormLivro';
import ListaLivros from './components/ListaLivros';
import Mensagem from './components/Mensagem';
import {
  listarLivros,
  listarGeneros,
  cadastrarLivro,
  atualizarLivro,
  excluirLivro,
} from './api';

const FORM_VAZIO = {
  titulo_livro: '',
  autor_livro: '',
  ano_livro: '',
  exemplares_livro: '',
  genero_id: '',
};

function App() {
  const [livros, setLivros] = useState([]);
  const [generos, setGeneros] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [versaoLista, setVersaoLista] = useState(0);
  const [form, setForm] = useState(FORM_VAZIO);
  const [idEditando, setIdEditando] = useState(null);
  const [mensagem, setMensagem] = useState('');

  // READ: roda ao abrir e toda vez que versaoLista muda
  useEffect(() => {
    async function carregar() {
      try {
        setLivros(await listarLivros());
      } catch (erro) {
        setMensagem(erro.message);
      } finally {
        setCarregando(false);
      }
    }
    carregar();
  }, [versaoLista]);

  // os gêneros não mudam: carrega uma vez só
  useEffect(() => {
    async function carregar() {
      try {
        setGeneros(await listarGeneros());
      } catch (erro) {
        setMensagem(erro.message);
      }
    }
    carregar();
  }, []);

  function recarregarLista() {
    setVersaoLista(versaoLista + 1);
  }

  function alterarCampo(evento) {
    const { name, value } = evento.target;
    setForm({ ...form, [name]: value });
  }

  function limparForm() {
    setForm(FORM_VAZIO);
    setIdEditando(null);
  }

  function montarDados() {
    return {
      titulo_livro: form.titulo_livro,
      autor_livro: form.autor_livro,
      ano_livro: Number(form.ano_livro),
      exemplares_livro: Number(form.exemplares_livro),
      genero_id: Number(form.genero_id),
    };
  }

  // CREATE e UPDATE
  async function salvar() {
    try {
      if (idEditando) {
        await atualizarLivro(idEditando, montarDados());
        setMensagem('Livro atualizado.');
      } else {
        await cadastrarLivro(montarDados());
        setMensagem('Livro cadastrado.');
      }
      limparForm();
      recarregarLista();
    } catch (erro) {
      setMensagem(erro.message);
    }
  }

  function editar(livro) {
    setForm(livro);
    setIdEditando(livro.id_livro);
  }

  // DELETE
  async function excluir(livro) {
    if (!confirm(`Excluir "${livro.titulo_livro}"?`)) {
      return;
    }
    try {
      await excluirLivro(livro.id_livro);
      setMensagem('Livro excluído.');
      recarregarLista();
    } catch (erro) {
      setMensagem(erro.message);
    }
  }

  return (
    <main>
      <Cabecalho total={livros.length} />
      {carregando && <Mensagem tipo="aviso" texto="Carregando..." />}
      {mensagem && <Mensagem tipo="aviso" texto={mensagem} />}
      <FormLivro
        form={form}
        generos={generos}
        editando={idEditando !== null}
        onAlterar={alterarCampo}
        onSalvar={salvar}
        onCancelar={limparForm}
      />
      <ListaLivros
        livros={livros}
        generos={generos}
        onEditar={editar}
        onExcluir={excluir}
      />
    </main>
  );
}

export default App;
