const API_URL = import.meta.env.VITE_API_URL;

// GET /livros
export async function listarLivros() {
  const resposta = await fetch(`${API_URL}/livros`);
  if (!resposta.ok) {
    throw new Error('Não foi possível carregar os livros.');
  }
  return resposta.json();
}

// GET /generos
export async function listarGeneros() {
  const resposta = await fetch(`${API_URL}/generos`);
  if (!resposta.ok) {
    throw new Error('Não foi possível carregar os gêneros.');
  }
  return resposta.json();
}

// POST /livros
export async function cadastrarLivro(livro) {
  const resposta = await fetch(`${API_URL}/livros`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(livro),
  });
  if (!resposta.ok) {
    const corpo = await resposta.json();
    throw new Error(corpo.erro);
  }
  return resposta.json();
}

// PUT /livros/:id
export async function atualizarLivro(id, livro) {
  const resposta = await fetch(`${API_URL}/livros/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(livro),
  });
  if (!resposta.ok) {
    const corpo = await resposta.json();
    throw new Error(corpo.erro);
  }
  return resposta.json();
}

// DELETE /livros/:id  (204: sem corpo, sem .json())
export async function excluirLivro(id) {
  const resposta = await fetch(`${API_URL}/livros/${id}`, {
    method: 'DELETE',
  });
  if (!resposta.ok) {
    const corpo = await resposta.json();
    throw new Error(corpo.erro);
  }
}
