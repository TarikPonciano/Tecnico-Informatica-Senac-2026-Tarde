import { useEffect, useState } from 'react';
import Cabecalho from './components/Cabecalho';
import ListaLivros from './components/ListaLivros';
import Mensagem from './components/Mensagem';

const API_URL = import.meta.env.VITE_API_URL;

function App() {
  const [livros, setLivros] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');

  useEffect(() => {
    async function carregarLivros() {
      try {
        const resposta = await fetch(`${API_URL}/livros`);
        if (!resposta.ok) {
          throw new Error('Erro ' + resposta.status);
        }
        const dados = await resposta.json();
        setLivros(dados);
      } catch (e) {
        console.error(e.message);
        setErro('Não foi possível carregar os livros.');
      } finally {
        setCarregando(false);
      }
    }
    carregarLivros();
  }, []);

  return (
    <main>
      <Cabecalho total={livros.length} />
      {carregando && <Mensagem tipo="aviso" texto="Carregando..." />}
      {erro && <Mensagem tipo="erro" texto={erro} />}
      <ListaLivros livros={livros} />
    </main>
  );
}

export default App;
