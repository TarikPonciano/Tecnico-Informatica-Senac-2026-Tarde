function Mensagem({ tipo, texto }) {
  return <p className={tipo}>{texto}</p>;
}

export default Mensagem;
