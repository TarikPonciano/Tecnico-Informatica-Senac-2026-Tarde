import { useState } from 'react';
import CampoBusca from './CampoBusca';
import CartaoLivro from './CartaoLivro';

function ListaLivros({ livros }) {
  const [busca, setBusca] = useState('');

  const livrosFiltrados = livros.filter((livro) =>
    livro.titulo_livro.toLowerCase().includes(busca.toLowerCase())
  );

  return (
    <>
      <CampoBusca valor={busca} onBuscar={setBusca} />
      <div className="grade">
        {livrosFiltrados.map((livro) => (
          <CartaoLivro key={livro.id_livro} livro={livro} />
        ))}
      </div>
    </>
  );
}

export default ListaLivros;
