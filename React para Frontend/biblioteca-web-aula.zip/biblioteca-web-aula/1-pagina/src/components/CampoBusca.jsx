function CampoBusca({ valor, onBuscar }) {
  return (
    <input
      className="busca"
      placeholder="Buscar pelo título..."
      value={valor}
      onChange={(evento) => onBuscar(evento.target.value)}
    />
  );
}

export default CampoBusca;
