function CartaoLivro({ livro }) {
  return (
    <div className="cartao">
      <h2>{livro.titulo_livro}</h2>
      <p>{livro.autor_livro}</p>
      <p className="detalhe">
        {livro.ano_livro} · {livro.exemplares_livro} exemplares
      </p>
    </div>
  );
}

export default CartaoLivro;
