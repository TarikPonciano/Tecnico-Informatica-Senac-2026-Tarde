function Cabecalho({ total }) {
  return (
    <header className="cabecalho">
      <h1>Biblioteca</h1>
      <p>{total} livros no acervo</p>
    </header>
  );
}

export default Cabecalho;
